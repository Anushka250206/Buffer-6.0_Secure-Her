# session.py
current_user = [None]
