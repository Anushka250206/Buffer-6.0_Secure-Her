# Buffer-6.0

The themes for Buffer 6.0 are -

1. FinTech

2. Women Safety

3. Next-Gen Academic Solutions

4. Custom Data Structure
